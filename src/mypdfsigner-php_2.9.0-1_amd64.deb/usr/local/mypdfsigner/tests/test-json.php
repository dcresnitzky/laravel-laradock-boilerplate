<?php
# (c) 2009-2017 KryptoKoder LLC

# this is a variation of the basic example in that the confFile entry is not the path
# to the configuration file but rather a json object that can have any name=value pair
# that exists in the configuration file, including the name "conffile" whose value is
# the configuration file itself. entries in the json object take precedence over similar
# entries in the configuration file. the meaning of the entries in the json object and
# the configuration file is the same except for two entries, certfile and certpasswd.
#
# certfile in the configuration file is the path to the pkcs#12 keystore while in the
# json object is the base64 encoding of the bytes of the pkcs#12 keystore;
# certpasswd in the configuration file is the encrypted value of the password for the 
# pkcs#12 keystore while in the json object is the decrypted (plain text) value

$inputPDF = "/usr/local/mypdfsigner/tests/example.pdf";
$outputPDF = "/tmp/example-signed-php.pdf";
$password = ""; # if non empty document will also be encrypted
$location = "PHP Location";
$reason = "PHP Reason";
$visible = TRUE;
$certify = TRUE;
$timestamp = TRUE;
$title = "PHP Title";
$author = "PHP Author";
$subject = "PHP Subject";
$keywords = "PHP Keywords";
# build json config
$certfile = chunk_split(base64_encode(file_get_contents("/usr/local/mypdfsigner/tests/mypdfsigner-test.p12")));
$certpasswd = "mypdfsigner";
$conffile = "/usr/local/mypdfsigner/tests/mypdfsigner.conf";
$confFile = json_encode(array('conffile' => $conffile, 'certfile' => $certfile, 'certpasswd' => $certpasswd));

$signResult = mypdfsigner_add_metadata_sign($inputPDF, $outputPDF, $password, $location, $reason, $visible, $certify, $timestamp, $title, $author, $subject, $keywords, $confFile);

echo $signResult . "\n";

?>
