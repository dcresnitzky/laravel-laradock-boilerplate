<?php
# (c) 2009-2017 KryptoKoder LLC

$inputPDF = "/usr/local/mypdfsigner/tests/example.pdf";
$outputPDF = "/tmp/example-signed-php.pdf";
$password = ""; # if non empty document will also be encrypted
$location = "PHP Location";
$reason = "PHP Reason";
$visible = TRUE;
$certify = TRUE;
$timestamp = TRUE;
$title = "PHP Title";
$author = "PHP Author";
$subject = "PHP Subject";
$keywords = "PHP Keywords";
$confFile = "/usr/local/mypdfsigner/tests/mypdfsigner.conf";

$signResult = mypdfsigner_add_metadata_sign($inputPDF, $outputPDF, $password, $location, $reason, $visible, $certify, $timestamp, $title, $author, $subject, $keywords, $confFile);

echo $signResult . "\n";

$verifyResult = mypdfsigner_verify($outputPDF, $confFile);

echo $verifyResult . "\n";

?>
