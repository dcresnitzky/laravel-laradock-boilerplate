<?php
# (c) 2009-2017 KryptoKoder LLC

# this example shows how the signing can take place in a remote machine (like at the client side) while
# the document to sign never leaves the local machine.

# this example consists of 4 steps:
#
# (a) get info about the signer (name and certificate serial number) to embed in the document
# (b) prepare the PDF for signing and get associated hash
# (c) create the signature over the hash
# (d) embed the signature in the prepared PDF

# step (a): info about signer
# this information is relevant if using visible signatures that include the name of the signer (since we want
# that to match the signer name in the certificate). this information can be extracted either from a PKCS#12
# store or from the certificate in PEM format

$conffile = "/usr/local/mypdfsigner/tests/mypdfsigner.conf";

$signerInfoResult = mypdfsigner_get_signer_info($conffile);

echo $signerInfoResult . "\n";

$signerData = explode("#", $signerInfoResult);
if ($signerData[0] != "0") {
  echo "Error: " . $signerData[1] . "\n";
  exit(1);
}
$signerCert = explode("|", $signerData[1]);
$signerName = $signerCert[0];
$certSN = $signerCert[1];

# step (b): prepare PDF document
# prepare de document for signing and return the associated hash

$inputPDF = "/usr/local/mypdfsigner/tests/example.pdf";
$outputPDF = "/tmp/example-signed-php.pdf";
$password = "";
$location = "PHP Location";
$reason = "PHP Reason";
$visible = TRUE;
$certify = TRUE;
$title = "PHP Title";
$author = "PHP Author";
$subject = "PHP Subject";
$keywords = "PHP Keywords";
$extrarange = "11860";
$confFile = json_encode(array('conffile' => $conffile, 'extrarange' => $extrarange));

$prepareSignatureResult = mypdfsigner_add_metadata_prepare_signature($inputPDF, $outputPDF, $password, $location, $reason, $visible, $certify, $signerName, $certSN, $title, $author, $subject, $keywords, $confFile);

echo $prepareSignatureResult . "\n";

$hashData = explode("#", $prepareSignatureResult);
if ($hashData[0] != "0") {
  echo "Error: " . $signerData[1] . "\n";
  exit(1);
}
$hash = $hashData[1];

# step (c): create signature over the hash
$timestamp = TRUE;

$createSignatureResult = mypdfsigner_create_signature($hash, $timestamp, $confFile);

echo $createSignatureResult . "\n";

$signatureData = explode("#", $createSignatureResult);
if ($signatureData[0] != "0") {
  echo "Error: " . $signatureData[1] . "\n";
  exit(1);
}
$signature = $signatureData[1];

# step (d): embed the signature in the prepared PDF

$applySignatureResult = mypdfsigner_apply_signature($outputPDF, $signature);

echo $applySignatureResult . "\n"

?>
