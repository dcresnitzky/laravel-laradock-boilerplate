<?php
# (c) 2009-2017 KryptoKoder LLC

# this example corresponds to step (d) of test-external.php; read it for more info
#

$outputPDF = "/tmp/example-" . $_POST['output_file'] . "-signed.pdf";
$signature = $_POST['signature'];

# step (d): embed the signature in the prepared PDF

$applySignatureResult = mypdfsigner_apply_signature($outputPDF, $signature);

echo $applySignatureResult;

?>
