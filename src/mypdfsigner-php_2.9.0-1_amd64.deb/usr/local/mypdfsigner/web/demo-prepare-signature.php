<?php
# (c) 2009-2017 KryptoKoder LLC

# this example corresponds to step (b) of test-external.php; read it for more info
#
# (b) prepare the PDF for signing and get associated hash
#

$conffile = "/usr/local/mypdfsigner/tests/mypdfsigner.conf";

$outputPDF = "/tmp/example-" . $_POST['output_file'] . "-signed.pdf";
$signerName = $_POST['signer_name'];
$certSN = $_POST['cert_sn'];
$extrarange = $_POST['extra_range'];
$sigrect = $_POST['sig_rect'];
$sigtext = $_POST['sig_text'];
$sigreason = $_POST['sig_reason'];
$sigloc = $_POST['sig_loc'];
$sigimagebase64 = $_POST['sig_image'];
$sigimage = "";

# step (b): prepare PDF document
# prepare the document for signing and return the associated hash

$inputPDF = "/usr/local/mypdfsigner/tests/example.pdf";
$password = "";
$location = $sigloc;
$reason = $sigreason;
$visible = FALSE;
$certify = FALSE;
$title = "PHP Title";
$author = "PHP Author";
$subject = "PHP Subject";
$keywords = "PHP Keywords";

$confarray = array();
$confarray['conffile'] = $conffile;
$confarray['extrarange'] = $extrarange;
if (!empty($sigrect)) {
  $visible = TRUE;
  $confarray['sigrect'] = $sigrect;
}
if (!empty($sigtext)) {
  $confarray['sigtext'] = $sigtext;
}
if (!empty($sigimagebase64)) {
  $sigimage = "/tmp/" . md5($sigimagebase64) . ".png";
  if (!file_exists($sigimage)) {
    $fp = fopen($sigimage, "wb");
    fwrite($fp, base64_decode($sigimagebase64));
    fclose($fp);
  }
  $confarray['sigimage'] = $sigimage;
}

$confFile = json_encode($confarray);

$prepareSignatureResult = mypdfsigner_add_metadata_prepare_signature($inputPDF, $outputPDF, $password, $location, $reason, $visible, $certify, $signerName, $certSN, $title, $author, $subject, $keywords, $confFile);

echo $prepareSignatureResult;

?>
